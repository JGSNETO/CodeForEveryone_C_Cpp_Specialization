#pragma once
#ifndef PLAYER_H
#define PLAYER_H

enum class Player { BLUE, RED };

#endif // PLAYER_H